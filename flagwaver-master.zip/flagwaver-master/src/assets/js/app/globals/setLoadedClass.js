export default function setLoadedClass() {
    document.documentElement.className += ' loaded';
}
