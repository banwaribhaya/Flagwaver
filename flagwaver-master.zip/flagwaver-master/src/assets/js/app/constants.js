//
// Static constants
//

export const SceneryBackground = {
    CLASSIC: 'classic',
    BLUE_SKY: 'blue-sky',
    NIGHT_SKY_CLOUDS: 'night-sky-clouds',
    CUSTOM: 'custom'
};
