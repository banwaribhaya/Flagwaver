/*!
 * FlagWaver
 * @author krikienoid / https://github.com/krikienoid
 *
 * A web app for simulating a waving flag.
 */

import './app';
