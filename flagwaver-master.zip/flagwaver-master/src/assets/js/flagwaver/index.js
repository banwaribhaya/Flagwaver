import * as FlagWaver from './FlagWaver';

export * from './FlagWaver';

export default FlagWaver;
